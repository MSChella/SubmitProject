package com.numadic.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import com.numadic.base.BaseClass;
import com.numadic.pageobjects.CareersPage;
import com.numadic.pageobjects.JobDetailsPage;

public class CareersPageTest extends BaseClass {

	CareersPage careerspage;
	JobDetailsPage jobdetailspage;

	@BeforeMethod
	public void setup() {

		launchApp();
	}

	@AfterMethod
	public void teardown() {
		driver.quit();

	}
   @Test(priority=1)
   public void verifyHeader() throws Throwable {

		careerspage = new CareersPage();
		boolean result = careerspage.validateHeader();
		Assert.assertTrue(result);
	}
   
   @Test(priority=2)
 public void verifyMessage() {
	boolean result = careerspage.selectInternship().isDisplayed();
	Assert.assertTrue(result);
 }
 @Test(priority=3)
   public void verifyUrl() {
	 
	 String actUrl = careerspage.getUrl();
	 String expUrl = "https://numadic.com/careers/qa-engineer.php";
	 Assert.assertEquals(actUrl, expUrl);
	   
   }
   @Test(priority=4)
   public void verifyApplyOMBtn() {
	  boolean result = jobdetailspage.clickApplyNow().isDisplayed();
	  Assert.assertTrue(result);
   }
   
     
}
