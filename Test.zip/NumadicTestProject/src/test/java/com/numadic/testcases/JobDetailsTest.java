package com.numadic.testcases;

public class JobDetailsTest {

}
