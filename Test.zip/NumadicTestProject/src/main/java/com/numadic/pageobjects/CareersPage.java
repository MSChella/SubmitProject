package com.numadic.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.numadic.actiondriver.ActionClass;
import com.numadic.base.BaseClass;

public class CareersPage extends BaseClass {


    JobDetailsPage jobdetailspage;
	Actions actions;
	
	@FindBy(xpath = "//h1[contains(text(),'JOIN OUR CREW')]")
	WebElement pageTitle;

	@FindBy(xpath = "//select[@id='job_type']")
	WebElement jobTypeDrpdwn;

	@FindBy(xpath = "//td[contains(text(),'There are no available job positions that match yo')]")
	WebElement message;

	@FindBy(xpath = "//a[contains(text(),'QA Engineer')]")
	WebElement qajobselection;

	@FindBy(xpath = "//tbody/tr[10]/td[5]/button[1]")
	WebElement jobapplybtn;
	
	@FindBy(xpath="//select[@id='job_location']")
	WebElement jobApplyQA;

	public CareersPage() {
		PageFactory.initElements(driver, this);
	}

		
	public boolean validateHeader() {
		return ActionClass.isDisplayed(driver, pageTitle);
	}

	
	
	
public WebElement selectInternship() {
	ActionClass.selectByIndex(jobTypeDrpdwn, 3);
	return message;
}

	public JobDetailsPage selectFullTime(String job) {
		ActionClass.selectByIndex(jobTypeDrpdwn, 1);
		actions.moveToElement(qajobselection).click().build().perform();
		return new JobDetailsPage();
		

	}
	public String getUrl() {
		
		String currentPgUrl = driver.getCurrentUrl();
		return currentPgUrl;
		}
	
	
		public JobDetailsPage selectQAEngg() {
		
		actions.moveToElement(qajobselection).click().build().perform();
		return new JobDetailsPage();
	}
	
		
	public JobDetailsPage applyHereNow() {
		actions.moveToElement(jobapplybtn).click().build().perform();
		return new JobDetailsPage();
	}
	
	public void hoveroverApplyQA() {
		actions.moveToElement(jobApplyQA).click().build().perform();
	}
}
