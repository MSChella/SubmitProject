package com.numadic.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.numadic.actiondriver.ActionClass;
import com.numadic.base.BaseClass;

public class ApplicationPage extends BaseClass {

	@FindBy(xpath = "//input[@id='firstName']")
	WebElement firstnametxtbox;

	@FindBy(xpath = "//input[@id='lastName']")
	WebElement lstnametxtbox;

	@FindBy(xpath = "//input[@id='email']")
	WebElement emailtextbox;

	@FindBy(xpath = "//input[@id='email']")
	WebElement mblnobox;

	@FindBy(xpath = "//select[@id='sports']")
	WebElement slctsportsdrpdwn;

	@FindBy(xpath = "//select[@id='pets']")
	WebElement spetsdrpdwn;

	@FindBy(xpath = "//input[@id='current_city']")
	WebElement currntcitytxtbox;

	@FindBy(xpath = "//input[@id='hometown']")
	WebElement hmetwnbox;

	@FindBy(xpath = "//input[@id='dob']")
	WebElement dobtxtbox;

	public ApplicationPage() {

		PageFactory.initElements(driver, this);
	}

	public void verifyFNameBox() {

		boolean result = ActionClass.isEnabled(driver, lstnametxtbox);
		Assert.assertTrue(result);
	}

	public void verifyLNameBox() {

		boolean result = ActionClass.isEnabled(driver, lstnametxtbox);
		Assert.assertTrue(result);
	}

	public void verifyEmail() {
		boolean result = ActionClass.isEnabled(driver, emailtextbox);
		Assert.assertTrue(result);
	}

	public void verifyMbField() {
		boolean result = ActionClass.isEnabled(driver, mblnobox);
		Assert.assertTrue(result);

	}

	public void verifySpoField() {
		boolean result = ActionClass.isEnabled(driver, slctsportsdrpdwn);
		Assert.assertTrue(result);
	}

	public void verifyAniField() {
		boolean result = ActionClass.isEnabled(driver, spetsdrpdwn);
		Assert.assertTrue(result);
	}

	public void verifyCrrntCity() {

		boolean result = ActionClass.isEnabled(driver, currntcitytxtbox);
		Assert.assertTrue(result);

	}

	public void verifyHmwTwn() {
		boolean result = ActionClass.isEnabled(driver, hmetwnbox);
		Assert.assertTrue(result);

	}

	public void verifyDoB() {

		boolean result = ActionClass.isEnabled(driver, dobtxtbox);
		Assert.assertTrue(result);
	}

}
