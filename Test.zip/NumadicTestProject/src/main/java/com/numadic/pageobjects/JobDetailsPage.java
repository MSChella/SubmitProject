package com.numadic.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.numadic.actiondriver.ActionClass;
import com.numadic.base.BaseClass;

public class JobDetailsPage extends BaseClass {

	Actions actions;

	@FindBy(xpath = "//a[contains(text(),'Apply here now')]")
	WebElement applyqabtn;

	public JobDetailsPage() {

		PageFactory.initElements(driver, this);
	}

	public WebElement clickApplyNow() {

		ActionClass.findElement(driver, applyqabtn);
		return applyqabtn;

	}

	public String validateUrl() {
		String jurl = driver.getCurrentUrl();
		return jurl;
	}
}
