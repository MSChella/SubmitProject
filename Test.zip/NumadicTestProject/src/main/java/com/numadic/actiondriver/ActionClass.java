package com.numadic.actiondriver;


import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.numadic.base.BaseClass;

public class ActionClass extends BaseClass {

	public static void scrollByVisibilityofElement(WebDriver driver, WebElement ele) {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", ele);

	}

	public static void click(WebDriver ldriver, WebElement locatorName) {

		Actions act = new Actions(ldriver);
		act.moveToElement(locatorName).click().build().perform();

	}

	public static boolean findElement(WebDriver ldriver, WebElement ele) {

		boolean flag = false;
		try {
			ele.isDisplayed();
			flag = true;
		} catch (Exception e) {
			flag = false;
		} finally {
			if (flag) {
				System.out.println("Sucessfully found element at");

			} else {
				System.out.println("Unable to locate element at");
			}
		}
		return flag;
	}

	public static boolean isDisplayed(WebDriver ldriver, WebElement ele) {

		boolean flag = false;
		flag = findElement(ldriver, ele);
		if (flag) {
			flag = ele.isDisplayed();
			if (flag) {
				System.out.println("The Element is Displayed");
			} else {
				System.out.println("The Element is Not Displayed");
			}
		} else {
			System.out.println("Not Displayed");
		}
		return flag;
	}

	public static boolean isSelected(WebDriver ldriver, WebElement ele) {

		boolean flag = false;
		flag = findElement(ldriver, ele);
		if (flag) {
			flag = ele.isSelected();
			if (flag) {
				System.out.println("The Element is Selected");
			} else {
				System.out.println("The Element is Not Selected");
			}
		} else {
			System.out.println("Not Selected");
		}
		return flag;
	}

	public static boolean isEnabled(WebDriver ldriver, WebElement ele) {

		boolean flag = false;
		flag = findElement(ldriver, ele);
		if (flag) {
			flag = ele.isEnabled();
			if (flag) {
				System.out.println("The Element is Enabled");
			} else {
				System.out.println("The Element is Not Enabled");
			}
		} else {
			System.out.println("Not Enabled");
		}
		return flag;
	}

	public static boolean type(WebElement ele, String text) {

		boolean flag = false;
		try {
			flag = ele.isDisplayed();
			ele.clear();
			ele.sendKeys(text);
			flag = true;
		} catch (Exception e) {
			System.out.println("Location Not Found");
			flag = false;
		} finally {
			if (flag) {
				System.out.println("Sucessfully entered the value");
			} else {
				System.out.println("Unable to Enter Value");
			}
		}
		return flag;
	}

	public static boolean selectBySendkeys(WebElement ele, String value) {
		boolean flag = false;
		try {
			ele.sendKeys(value);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Select Value from Dropdown");
			} else {
				System.out.println("Not Selected Value from the Dropdown");
			}
		}
	}

	public static boolean selectByIndex(WebElement element, int index) {

		boolean flag = false;
		try {
			Select s = new Select(element);
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Option Selected By Index");
			} else {
				System.out.println("Option Not Selected By Index");
			}
		}
	}

	public static boolean selectByValue(WebElement element, String value) {

		boolean flag = false;
		try {
			Select s = new Select(element);
			s.selectByValue(value);
			flag = true;
			return flag;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Option Selected By Value");
			} else {
				System.out.println("Option Not Selected By Value");
			}
		}
	}

	public static boolean selectByVisibleText(String visibletext, WebElement element) {
		boolean flag = false;

		try {
			Select s = new Select(element);
			s.selectByVisibleText(visibletext);
			flag = true;
			return flag;
		} catch (Exception e) {
			return false;
		} finally {
			if (flag) {
				System.out.println("Option Selected By VisibleText");
			} else {
				System.out.println("Option Not Selected By VisibleText");
			}
		}

	}


	public boolean JSClick(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);
			// driver.executeAsyncScript("arguments[0].click();", element);

			flag = true;

		}

		catch (Exception e) {
			throw e;

		} finally {
			if (flag) {
				System.out.println("Click Action is performed");
			} else if (!flag) {
				System.out.println("Click Action is not performed");
			}
		}
		return flag;
	}

	// public boolean switchToFrameByIndex(WebDriver driver, int index) {
	// boolean flag = false;
	// try {
	// WebDriverWait wait= new WebDriverWait(driver, 15);
	// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//iframe")));
	// driver.switchTo().frame(index);
	// flag = true;
	// return true;
	// } catch (Exception e) {

	// return false;
	// } finally {
	// if (flag) {
	// System.out.println("Frame with index \"" + index + "\" is selected");
	// } else {
	// System.out.println("Frame with index \"" + index + "\" is not selected");
	// }
	// }
	// }

	public boolean switchToFrameById(WebDriver driver, String idValue) {
		boolean flag = false;
		try {
			driver.switchTo().frame(idValue);
			flag = true;
			return true;
		} catch (Exception e) {

			e.printStackTrace();
			return false;
		} finally {
			if (flag) {
				System.out.println("Frame with Id \"" + idValue + "\" is selected");
			} else {
				System.out.println("Frame with Id \"" + idValue + "\" is not selected");
			}
		}
	}

	public boolean switchToFrameByName(WebDriver driver, String nameValue) {
		boolean flag = false;
		try {
			driver.switchTo().frame(nameValue);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag) {
				System.out.println("Frame with Name \"" + nameValue + "\" is selected");
			} else if (!flag) {
				System.out.println("Frame with Name \"" + nameValue + "\" is not selected");
			}
		}
	}

	public boolean switchToDefaultFrame(WebDriver driver) {
		boolean flag = false;
		try {
			driver.switchTo().defaultContent();
			flag = true;
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			if (flag) {
				// SuccessReport("SelectFrame ","Frame with Name is selected");
			} else if (!flag) {
				// failureReport("SelectFrame ","The Frame is not selected");
			}
		}
	}

	public void mouseOverElement(WebDriver driver, WebElement element) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(element).build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag) {
				System.out.println(" MouserOver Action is performed on ");
			} else {
				System.out.println("MouseOver action is not performed on");
			}
		}
	}

	public boolean moveToElement(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			// WebElement element = driver.findElement(locator);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].scrollIntoView(true);", ele);
			Actions actions = new Actions(driver);
			// actions.moveToElement(driver.findElement(locator)).build().perform()
			actions.moveToElement(ele).build().perform();
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean mouseover(WebDriver driver, WebElement ele) {
		boolean flag = false;
		try {
			new Actions(driver).moveToElement(ele).build().perform();
			flag = true;
			return true;
		} catch (Exception e) {
			return false;
		} finally {
			/*
			 * if (flag) {
			 * SuccessReport("MouseOver ","MouserOver Action is performed on \""+locatorName
			 * +"\""); } else {
			 * failureReport("MouseOver","MouseOver action is not performed on \""
			 * +locatorName+"\""); }
			 */
		}
	}

	public static void implicitWait(WebDriver driver, int timeOut) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	public static void pageLoadTimeOut(WebDriver driver, int timeOut) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
	}
}
